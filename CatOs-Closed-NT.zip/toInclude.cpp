#include "c/iostream"
#include "c/fstream"
#include "c/cstring"
#include "c/cmath"
#include "c/cstdio"
#include "c/memory"
#include "c/stdexcept"
#include "c/string"
#include "c/array"
#include "lib.cpp"
using namespace std;
typedef string String;
typedef fstream fs;

System_out out;
System_in in;
File file;
Colors color;
Window window;
EventHandler handler;
Measure meas;

String input = "";

std::string exec(const char* cmd) {
    std::array<char, 128> buffer;
    std::string result;
    std::unique_ptr<FILE, decltype(&pclose)> pipe(popen(cmd, "r"), pclose);
    if (!pipe) {
        throw std::runtime_error("popen() failed!");
    }
    while (fgets(buffer.data(), buffer.size(), pipe.get()) != nullptr) {
        result += buffer.data();
    }
    return result;
}

void runcommand(String comm) {
    try {
        if(comm.find("(in)") != -1) {
            String p1 = comm.substr(0, comm.find("(in)"));
            String p2 = comm.substr(comm.find("(in)") + 4);
            comm = p1 + input + p2;
        }
    } catch(std::exception e) {}
    try {
    if(comm == ".help") {
            out.print("Lite Systems Help", "%n");
            out.print("Here is a list of the commands of this system:", "%n");
            String comms[2000] = {
                                    "exit -> Exit the system.",
                                    ".help -> Shows this list.",
                                    "get-fs -> Shows all files in the system folder",
                                    "cat --ver -> Shows the version of the OS",
                                    "print 'text' -> Prints the variable text with the determinated options",
                                    "cat -sta-key -> Shows the start key",
                                    "cat -debug 'filename' -> Runs the selected .cpm file",
                                    "clear -> Clears the window",
                                    "pause -> Pause the system",
                                    "'filename'.cpm or 'filename' -> Debugs a .cpm file",
                                    "readf 'filename' -> Shows the file content",
                                    "lbat-c 'command' -> Run the selected cmd command",
                                    "in -> Strores a user input in a variable called '(in)'",
                                    "date -> Changes the date",
                                    "get-cpm -> Gets all .cpm files in the directorie"
                                 };
            for(int i = 0; i < sizeof(comms) / sizeof(string); i++) {
                if(!comms[i].empty()) {
                    out.print(comms[i], "%n");
                }
            }
    } else if(comm == "in") {
        input = in.scani("%n");
    } else if(comm == "date") {
        system("date");
    } else if(comm == "get-fs") {
            system("dir");
    } else if(comm == "get-cpm") {
        String cpms = exec("dir *.cpm");
        out.print(cpms, "%s");
    } else if(comm == "cat --ver") {
        out.print("CatOS 1.1 - Lite Systems NT 2023.02.14 x_56.0 - NT x_11.0", "%n");
    } else if(comm.substr(0,6) == "print ") {
        out.print(comm.substr(6), "%n");
    } else if(comm == "cat -sta-key") {
        out.print("Start Key: CatOS-Sta01\nWrite this key in a safe place to initialize this OS later.", "%n");
    } else if(comm.substr(0,11) == "cat -debug ") {
        String filename = comm.substr(11), ac = "";
        fstream read(filename);
        while(getline(read,ac)) {
            runcommand(ac);
        }
        read.close();
    } else if(comm == "clear") {
        window.clear();
    } else if(comm == "pause") {
        window.pause();
    } else if(comm.substr(0,7) == "writef ") {
        String option1, option2;
        option1 = comm.substr(7, comm.substr(7).find(' '));
        option2 = comm.substr(comm.substr(7).find(' '));
        fs write(option1);
        write << option2;
        write.close();
    } else if(comm.substr(0,6) == "readf ") {
        String option1;
        option1 = comm.substr(6);
        String ac;
        fs write(option1);
       while(getline(write, ac)) {
        out.print(ac, "%n");
       }
        write.close();
    } else if(comm.substr(0,7) == "lbat-c ") {
        system(comm.substr(7).c_str());
        out.print("\n","%n");
    } else if(comm.substr(0,11) != "cat -debug " && comm.substr(comm.length() - 4) == ".cpm") {
        String filename = comm, ac = "";
        fstream read(filename);
        while(getline(read,ac)) {
            runcommand(ac);
        }
        read.close();
    } else if(comm == "exit") {} else {
        fs check(comm + ".cpm");
        String ac, tetoch;
        while(getline(check, ac)) {
            tetoch.append(ac);
        }
        if(!tetoch.empty()) {
            String filename = comm + ".cpm", ac = "";
        fstream read(filename);
        while(getline(read,ac)) {
            runcommand(ac);
        }
        read.close();
        } else {
            out.print("Unknow command or file: " + comm, "%n");
        }
    } 
    } catch(out_of_range e) {
        out.print("Unknow program or to short command: " + comm, "%n");
    }
}